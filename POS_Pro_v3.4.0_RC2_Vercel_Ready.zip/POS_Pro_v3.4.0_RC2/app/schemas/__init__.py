"""Validated API request schemas."""
